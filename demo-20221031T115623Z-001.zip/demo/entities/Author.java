package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user2")
public class Author {
	
	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", gmail=" + gmail + ", username=" + username + ", password="
				+ password + "]";
	}
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
	  int id;
	  String username;
	  String name;
	  String gmail;
      String password;
      public Author() {
		super();
		// TODO Auto-generated constructor stub
	  }
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGmail() {
		return gmail;
	}
	public void setGmail(String gmail) {
		this.gmail = gmail;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Author(int id, String name, String gmail, String username, String password) {
		super();
		this.id = id;
		this.name = name;
		this.gmail = gmail;
		this.username = username;
		this.password = password;
	}
	
    
}
