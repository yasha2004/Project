package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Repository.AuthorRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.entities.Author;
import com.example.demo.entities.Blog;

@Controller
public class MyController {
    
	@Autowired
	private BlogService blogService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AuthorRepository authorRepository;
	
	@GetMapping({"/about/{offset}"})
    private String pagination(@PathVariable int offset,Model model) {
        Page<Blog> productsWithPagination = blogService.findProductsWithPagination(offset,4);
        model.addAttribute("list",productsWithPagination);
        model.addAttribute("currentPage",offset);
        model.addAttribute("totalPages",productsWithPagination.getTotalPages());
        return "about";
    }
	
	@GetMapping({"/"})
    private String paginate(Model model) {
        Page<Blog> productsWithPaginate = blogService.findProductsWithPagination(0,4);
        model.addAttribute("list",productsWithPaginate);
        model.addAttribute("currentPage",0);
        model.addAttribute("totalPages",productsWithPaginate.getTotalPages());
        return "about";
    } 
	
	@GetMapping("/addData")
	public String addBlog(Model model) {
		Blog blog=new Blog();
		model.addAttribute("blog",blog);
		return "adddata";
	}
	
	@GetMapping("/fullBlog")
	public String fullBlog(@RequestParam int id,Model model) {
		model.addAttribute("list", blogService.getBlogById(id));
		return "fullblog";
	}
	
	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute Blog blog,Model model) {
		userRepository.save(blog);
		Page<Blog> productsWithPaginate = blogService.findProductsWithPagination(0,4);
        model.addAttribute("list",productsWithPaginate);
        model.addAttribute("currentPage",0);
        model.addAttribute("totalPages",productsWithPaginate.getTotalPages());
		return "about";
	}
	
	@GetMapping("/UpdateBlog")
	public String showUpdateForm(@RequestParam int id,Model model) {
		model.addAttribute("blog",blogService.getBlogById(id));
		return "adddata";
	}
	
	@GetMapping("/register")
	public String register(Model model) {
		Author author=new Author();
		model.addAttribute("author",author);
		return "register";
	}
	
	@PostMapping("/saveAuthor")
	public String saveUser(@ModelAttribute Author author,Model model) {
		authorRepository.save(author);
		return "signin";
	}
	
	
	@GetMapping("DeleteBlog")
	public String DeleteBlog(@RequestParam int id,Model model) {
		userRepository.deleteById(id);
		Page<Blog> productsWithPagination = blogService.findProductsWithPagination(0,4);
        model.addAttribute("list",productsWithPagination);
        model.addAttribute("currentPage",0);
        model.addAttribute("totalPages",productsWithPagination.getTotalPages());
		return "about";
	}

}
