//        Cookie token = WebUtils.getCookie(request, "token");
//    	String authHeader = "Bearer "+token.getValue();
//        String jwtToken=token.getValue();
//        response.setHeader("Authorization",authHeader);
//            jwtToken=requestTokenHeader.substring(7);

package com.example.demo.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.WebUtils;

import com.example.demo.helper.JwtUtil;
import com.example.demo.services.CustomUserDetailsService;

@Component
public class JwtAuthenticationFilter  extends OncePerRequestFilter {
	
    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        
    	
    	System.out.println("hello");
        Cookie token = WebUtils.getCookie(request, "token");
//    	String authHeader = "Bearer "+token.getValue();
//    	System.out.println(token);
//    	System.out.println(token.getValue());
        String requestTokenHeader = request.getHeader("Authorization");
        String username=null;
        String jwtToken=null;
        if(token!=null)
        jwtToken=token.getValue();
        
        System.out.println("jpt : "+jwtToken);
 
//        response.setHeader("Authorization",authHeader);
//        System.out.println(jwtToken);
       // requestTokenHeader!=null && requestTokenHeader.startsWith("Bearer ")
        if(jwtToken!=null)
        {
//            jwtToken=requestTokenHeader.substring(7);

            try{
            	System.out.println("hy");
                username = this.jwtUtil.extractUsername(jwtToken);
                System.out.println("username : "+username);
          
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            if(username!=null && SecurityContextHolder.getContext().getAuthentication()==null)
            {
   
                UserDetails userDetails = this.customUserDetailsService.loadUserByUsername(username);
                //security
                System.out.println(userDetails);

                UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());

                usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);

            }else
            {
                System.out.println("Token is not validated..");
            }

        }

        filterChain.doFilter(request,response);
    }
	
}
