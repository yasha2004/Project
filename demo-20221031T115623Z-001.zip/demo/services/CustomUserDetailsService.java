package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.AuthorRepository;
import com.example.demo.config.CustomAuthorDetails;
import com.example.demo.entities.Author;

import java.util.*;

@Service
public class CustomUserDetailsService implements UserDetailsService{

	@Autowired
	private AuthorRepository authorRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		Author author = authorRepository.findAuthorByGmail(username);
		System.out.println(author);
		if(author == null) {
			throw new UsernameNotFoundException("Could not found User!!");
		}
		
		CustomAuthorDetails customAuthor = new CustomAuthorDetails(author);
		return customAuthor;
		
	}
	
	

	

}
