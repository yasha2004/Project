package com.example.demo;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Blog;
import com.example.demo.helper.JwtUtil;
import com.example.demo.model.JwtRequest;
import com.example.demo.model.JwtResponse;
import com.example.demo.services.CustomUserDetailsService;

@Controller
public class JwtController {
     
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private BlogService blogService;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private CustomUserDetailsService customUserDetailsService;
	

	@GetMapping("/logOut")
	public String logout(HttpServletRequest request, HttpServletResponse response) {
		Cookie cookie = new Cookie("token", "");
		cookie.setMaxAge(0);
		response.addCookie(cookie);
		return "signin";
	}
	
	
	@PostMapping("/token")
	public String generateToken(JwtRequest jwtRequest,HttpServletResponse response,Model model) throws Exception
	{
		System.out.println("chal bee");
		System.out.println(jwtRequest);
		try {
			System.out.println("htt");
		    this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(),jwtRequest.getPassword()));
		    System.out.println("hahaha");
		}
		catch(UsernameNotFoundException e) {
			e.printStackTrace();
			throw new Exception("Bad Credentials");
		}
		System.out.println("hiili");
		UserDetails userDetails = this.customUserDetailsService.loadUserByUsername(jwtRequest.getUsername());
		String token = this.jwtUtil.generateToken(userDetails);
		System.out.println("JWT "+token);
		Cookie cookie = new Cookie("token", token);
		cookie.setMaxAge(-1);
		cookie.setSecure(true);
  		cookie.setHttpOnly(true);
		response.addCookie(cookie);
		System.out.println(cookie);
      Page<Blog> productsWithPaginate = blogService.findProductsWithPagination(0,4);
      model.addAttribute("list",productsWithPaginate);
      model.addAttribute("currentPage",0);
      model.addAttribute("totalPages",productsWithPaginate.getTotalPages());
      return "about";
//		return ResponseEntity.ok().body(new JwtResponse(token));
	}
	
	
}
