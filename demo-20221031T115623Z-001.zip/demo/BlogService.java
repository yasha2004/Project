package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.UserRepository;
import com.example.demo.entities.Blog;

@Service							
public class BlogService {
	@Autowired
	UserRepository userRepository;
	
	public List<Blog> getBlogs(){
		return userRepository.findAll();
	}
	public Blog getBlogById(int id) {
		return userRepository.findById(id).orElse(null);
	}
	
	public Blog saveBlog(int id,String author) {
		Blog blog=new Blog();
		blog.setId(id);
		blog.setAuthor(author);
		return userRepository.save(blog);
	}	
	
	public Page<Blog> findProductsWithPagination(int offset,int pageSize){
        Page<Blog> products = userRepository.findAll(PageRequest.of(offset, pageSize));
        return  products;
    }
	
	
}
